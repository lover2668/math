/**
 * Created by linxiao on 17/3/14.
 */
(function(){
    // 加载jquery
    var script = document.createElement("SCRIPT");
    script.src = 'https://code.jquery.com/jquery-1.12.4.js';
    script.type = 'text/javascript';
    document.getElementsByTagName("head")[0].appendChild(script);

    var jqueryReady = function(callback) {
        if (window.jQuery) {
            callback(jQuery);
        }
        else {
            window.setTimeout(function() { jqueryReady(callback); }, 20);
        }
    };

    jqueryReady(function($) {
        $(function() {
            var params = {};
            //获取url
            if(document) {
                params.url = document.URL || '';
            }
            if($_CONFIG){
                params.uid = $_CONFIG.uid || '';    //用户id，int类型
                params.course_type = $_CONFIG.course_type || '';// 课程类别，int类型（对应cid，1数学，2英语，3语文）
                params.course_id = $_CONFIG.course_id || '';// 课程id，int类型
                params.section_id = $_CONFIG.section_id || '';// 课次id，int类型（对应module_id）
                params.topic_id = $_CONFIG.topic_id || '';// 专题id，int类型
            }
            //params.page_begin_time = "";    // 页面进入时间, int时间戳
            params.page_begin_time = Date.parse(new Date())||'';
            params.actions = "";//行为动作，json文本，（暂时留空）
            /*
             $_CONFIG.ui:配置刷新的DOM id
             */
            if($_CONFIG.ui){
                //局部刷新:需要配置监听的板块id:$_CONFIG.ui
                var args = '';
                for(var i in params) {
                    if(args != '') {
                        args += '&';
                    }
                    args += i + '=' + encodeURIComponent(params[i]);
                }
                var title = $($_CONFIG.ui);//监控的节点
                title.bind('DOMNodeInserted', function(e) {
                    params.page_end_time = Date.parse(new Date())||'';
                    //拼接参数串
                    var args = '';
                    for(var i in params) {
                        if(args != '') {
                            args += '&';
                        }
                        args += i + '=' + encodeURIComponent(params[i]);
                    }
                    //通过Image对象请求后端脚本
                    var img = new Image(1, 1);
                    img.src = 'http://pool.51yxedu.com/index.php/index/Probe/p?' + args;
                    params.page_begin_time = Date.parse(new Date());
                });
            }else{
                //页面跳转
                window.onbeforeunload = function() {
                    params.page_end_time = Date.parse(new Date())||'';
                    //拼接参数串
                    var args = '';
                    for(var i in params) {
                        if(args != '') {
                            args += '&';
                        }
                        args += i + '=' + encodeURIComponent(params[i]);
                    }
                    //通过Image对象请求后端脚本
                    var img = new Image(1, 1);
                    img.src = 'http://pool.51yxedu.com/index.php/index/Probe/p?' + args;
                };
            }
        });
    });


})();